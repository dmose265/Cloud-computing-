Real time data collection 

Technologies Implemented:

1.IOT
Used for simulation of temperature collection data.
Platform: TinyOS & Tossim Live
Code: nesC (3 files), Python

The IOT simulation must be done by first compiling the MakeFile using 'make micaz sim' then running it as 'python runner.py'

D3.js VISUALIZATION:
Platform: Webstorm
Code: Javascript, css, html saved as index.html

CLOUD COMPUTING:
Platform : Google Drive

VIRTUALIZATION:
Platfrom: Oracle Virtualbox.


email: dmose@iu.edu.
Dennis Masigwa.
